export class AppSettings {

    public static API_ENDPOINT='http://localhost:8090/url';

 }
