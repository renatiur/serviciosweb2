import { Component, OnInit } from '@angular/core';
import { Cliente } from 'src/app/models/cliente.model';
import { Ubigeo } from 'src/app/models/ubigeo.model';
import { ClienteService } from 'src/app/services/cliente.service';
import { UbigeoService } from 'src/app/services/ubigeo.service';

@Component({
  selector: 'app-consulta-cliente',
  templateUrl: './consulta-cliente.component.html',
  styleUrls: ['./consulta-cliente.component.css']
})
export class ConsultaClienteComponent implements OnInit {

  nombre:string = "";
  dni:string = "";
  estado:number = -1;
  selDepartamento:string = "-1";
  selProvincia:string = "-1";
  selDistrito:number = -1;

  LstCliente:Cliente[] =[]

  departamentos: string[]  = [];
  provincias: string[]  = [];
  distritos: Ubigeo[]  = [];

  constructor(
    private clienteServices:ClienteService,
    private ubigeoServices:UbigeoService
  ) {

    ubigeoServices.listarDepartamento().subscribe(
      (x) => this.departamentos = x
  );
  }

  ngOnInit(): void {
  }

  cargaProvincia(){
    this.ubigeoServices.listaProvincias(this.selDepartamento).subscribe(
          (x)  => this.provincias = x
    );
    this.selProvincia  = "-1";
    this.distritos = [];
    this.selDistrito = -1;
  }
  cargaDistrito(){
      this.ubigeoServices.listaDistritos(this.selDepartamento, this.selProvincia).subscribe(
            (x)  => this.distritos = x
      );
      this.selDistrito = -1;
  }


  getClientexFiltro(){
    this.clienteServices.Consultar(this.nombre,this.dni,this.selDistrito,this.estado?1:0).subscribe(
      (res) =>{
        this.LstCliente = res.lista;
        alert(res.mensaje);
      }
    )
  }

}
