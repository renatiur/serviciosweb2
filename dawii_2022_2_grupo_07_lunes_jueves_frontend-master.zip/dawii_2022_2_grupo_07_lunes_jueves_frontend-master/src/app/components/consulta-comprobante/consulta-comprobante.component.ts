import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-comprobante',
  templateUrl: './consulta-comprobante.component.html',
  styleUrls: ['./consulta-comprobante.component.css']
})
export class ConsultaComprobanteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
