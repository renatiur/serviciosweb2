import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-producto',
  templateUrl: './consulta-producto.component.html',
  styleUrls: ['./consulta-producto.component.css']
})
export class ConsultaProductoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
