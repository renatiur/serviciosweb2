import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-sede',
  templateUrl: './consulta-sede.component.html',
  styleUrls: ['./consulta-sede.component.css']
})
export class ConsultaSedeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
