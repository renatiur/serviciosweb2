import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-usuario',
  templateUrl: './consulta-usuario.component.html',
  styleUrls: ['./consulta-usuario.component.css']
})
export class ConsultaUsuarioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
