import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Cliente } from 'src/app/models/cliente.model';
import { Ubigeo } from 'src/app/models/ubigeo.model';
import { ClienteService } from 'src/app/services/cliente.service';
import { UbigeoService } from 'src/app/services/ubigeo.service';
import Swal from 'sweetalert2'

declare var window: any;

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 1500
});

@Component({
  selector: 'app-crud-cliente',
  templateUrl: './crud-cliente.component.html',
  styleUrls: ['./crud-cliente.component.css']
})
export class CrudClienteComponent implements OnInit {

  LstCliente: Cliente[] = [];
  formModal: any;
  titulo: any;
  departamentos: string[] = [];
  provincias: string[] = [];
  distritos: Ubigeo[] = [];

  estado = 1;
  constructor(
    private clienteServices: ClienteService,
    private fb: FormBuilder,
    private ubigeoServices: UbigeoService

  ) {

    ubigeoServices.listarDepartamento().subscribe(
      (x) => this.departamentos = x
    );
  }

  submitted = false;

  formGuardarCliente = this.fb.group({
    idCliente: [0],
    nombres: ['', [Validators.required, Validators.pattern(/^([A-Za-zÁÉÍÓÚáéíóúÑñ]\s?){3,50}$/)]],
    apellidos: ['', [Validators.required, Validators.pattern(/^([A-Za-zÁÉÍÓÚáéíóúÑñ]\s?){3,50}$/)]],
    fechaNacimiento: [],
    dni: ['', [Validators.required, Validators.pattern(/^([0-9]){8}$/)]],
    correo: ['', [Validators.required, Validators.email]],
    direccion: ['', [Validators.required, Validators.pattern(/^([A-Za-zÁÉÍÓÚáéíóúÑñ0-9]\s?){3,50}$/)]],
    ubigeo: this.fb.group({
      idUbigeo: [-1, [Validators.required, Validators.pattern(/^[0-9]*$/)]],
      departamento: ['-1', [Validators.required,  Validators.pattern(/^([A-Za-zÁÉÍÓÚáéíóúÑñ]\s?){1,50}$/)]],
      provincia: ['-1', [Validators.required,  Validators.pattern(/^([A-Za-zÁÉÍÓÚáéíóúÑñ]\s?){1,50}$/)]]
    })
  });

  ngOnInit(): void {
    this.getClientexFiltro();
    this.formModal = new window.bootstrap.Modal(
      document.getElementById('exampleModal')
    );
    this.titulo = document.getElementById('idTituloModal');
  }

  cargaProvincia() {
    const FormUbigeo = this.formGuardarCliente.controls['ubigeo'].value
    this.ubigeoServices.listaProvincias(FormUbigeo['departamento']).subscribe(
      (x) => this.provincias = x
    );
    this.distritos = [];
  }
  cargaDistrito() {
    const FormUbigeo = this.formGuardarCliente.controls['ubigeo'].value
    this.ubigeoServices.listaDistritos(FormUbigeo['departamento'], FormUbigeo['provincia']).subscribe(
      (x) => this.distritos = x
    );
  }

  getClientexFiltro() {
    this.clienteServices.Consultar("", "", -1, -1).subscribe(
      (res) => {
        this.LstCliente = res.lista;
        this.LstCliente = this.LstCliente.reverse();
      }
    );
  }

  SaveCliente() {
    const getValueForms = JSON.stringify(this.formGuardarCliente.value);
    const newValues = JSON.parse(getValueForms);
    this.clienteServices.SaveCliente(newValues).subscribe((res) => {
      if (res.mensaje) {
        Toast.fire({
          icon: 'success',
          title: `${res.mensaje} ${newValues['nombres']} ${newValues['apellidos']}`
        });
        this.getClientexFiltro();
        this.formModal.hide();
        this.formGuardarCliente.reset();
      }
      else{
        Swal.fire({
          title: 'Error!',
          text: res.error,
          icon: 'error'
        });
      }
    })
  }

  AbrirModal() {
    this.formGuardarCliente.reset();
    const ubigeo = {
      departamento: '-1',
      provincia:'-1',
      idUbigeo: -1,
    }
    this.formGuardarCliente.controls['ubigeo'].setValue(ubigeo);
    this.formGuardarCliente.controls['idCliente'].setValue(0);
    this.formModal.show();
    this.titulo!.innerHTML = 'Registrar Cliente';
  }

  btnEditar(i: Cliente) {
    this.formModal.show();
    this.titulo!.innerHTML = `Editar Cliente: ${i.nombres} ${i.apellidos}`;
    this.setValuesForm(i);
  }

  btnEliminar(i: Cliente) {
    this.clienteServices.Eliminar(i.idCliente!).subscribe((res) => {
      if (res.mensaje) {
        Toast.fire({
          icon: 'success',
          title: `${res.mensaje} de ${i.nombres} ${i.apellidos}`
        });
        this.getClientexFiltro();
        this.formModal.hide();
      }
      else{
        Toast.fire({
          icon: 'error',
          title: `${res.error} a ${i.nombres} ${i.apellidos}`
        });
      }
    });
  }

  actualizaEstado(i:Cliente){
    i.estado = i.estado == 0? 1 :0;
    this.clienteServices.SaveEstado(i).subscribe((res)=>{
      if (res.mensaje) {
        Toast.fire({
          icon: 'success',
          title: `${res.mensaje} de ${i.nombres} ${i.apellidos}`
        });
        this.getClientexFiltro();
      }
      else{
        Toast.fire({
          icon: 'error',
          title: `${res.error}`
        });
      }
    });
  }

  setValuesForm(i: Cliente) {
    this.formGuardarCliente.patchValue({
      idCliente: i.idCliente,
      nombres: i.nombres,
      apellidos: i.apellidos,
      fechaNacimiento: i.fechaNacimiento,
      dni: i.dni,
      correo: i.correo,
      direccion: i.direccion,
    });
    const ubigeo = {
      departamento: i.ubigeo?.departamento,
      provincia: i.ubigeo?.provincia,
      idUbigeo: i.ubigeo?.idUbigeo,
    }
    this.cargarUbigeoAct(i);
    this.formGuardarCliente.controls['ubigeo'].setValue(ubigeo);

  }

  cargarUbigeoAct(i: Cliente) {
    this.ubigeoServices.listaProvincias(i.ubigeo?.departamento).subscribe(
      (x) => this.provincias = x
    );
    this.ubigeoServices.listaDistritos(i.ubigeo?.departamento, i.ubigeo?.provincia).subscribe(
      (x) => this.distritos = x
    );
  }

  isValidInput(input:string):boolean{
    return ((this.formGuardarCliente.get(input)!.touched || this.formGuardarCliente.get(input)!.dirty)
    && !this.formGuardarCliente.get(input)!.valid
    );
  }



}
