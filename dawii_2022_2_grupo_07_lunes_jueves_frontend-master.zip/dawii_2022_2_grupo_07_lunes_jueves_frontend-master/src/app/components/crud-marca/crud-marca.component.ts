import { Component, OnInit } from '@angular/core';
import { Marca } from 'src/app/models/marca.model';
import { Pais } from 'src/app/models/pais.model';
import { MarcaService } from 'src/app/services/marca.service';
import { PaisService } from 'src/app/services/pais.service';



@Component({
  selector: 'app-crud-marca',
  templateUrl: './crud-marca.component.html',
  styleUrls: ['./crud-marca.component.css']
})
export class CrudMarcaComponent implements OnInit {

  marcas: Marca[] = [];
  pais: Pais[]  = [];
  filtro: string ="";
  
  
  marca: Marca = { 
  idMarca:0,
  nombre:"",
  descripcion:"",
  fechaVigencia:new Date(),
  certificado:"",
  pais:{
    idPais:-1
    }
  };

  

 constructor(private marcaService:MarcaService, private paisService:PaisService) {
     this.paisService.listaPais().subscribe(
         response => this.pais = response
     );            
 }

 ngOnInit(): void {
 }

 consulta(){
  this.marcaService.listaMarcaNom(this.filtro==""?"todos":this.filtro).subscribe(
        (x) => this.marcas = x
  );
}

 actualizaEstado(aux : Marca){
       aux.estado = aux.estado == 1?0:1;
       this.marcaService.actualizaMarca(aux).subscribe();
 }

 

 registra(){
  
  this.marcaService.insertaMarca(this.marca).subscribe(
        (x) => {
          document.getElementById("btn_reg_limpiar")?.click();
          document.getElementById("btn_reg_cerrar")?.click();
          alert(x.mensaje);
          this.marcaService.listaMarcaNom(this.filtro==""?"todos":this.filtro).subscribe(
                  (x) => this.marcas = x
          );
        } 
  );

  

  this.marca = { 
    nombre:"",
    descripcion:"",
    fechaVigencia:new Date(),
    certificado:"",
    estado:1,
    pais:{
      idPais:-1
      }
    }
}

 buscar(aux :Marca){
  this.marca  = aux;
}

 actualiza(){
   this.marcaService.actualizaMarca(this.marca).subscribe(
         (x) => {
          document.getElementById("btn_act_limpiar")?.click();
          document.getElementById("btn_act_cerrar")?.click();
           alert(x.mensaje);
           this.marcaService.listaMarcaNom(this.filtro==""?"todos":this.filtro).subscribe(
            (x) => this.marcas = x   
          );   
        }    
   );

   //limpiar los comobobox
   
   

   //limpiar los componentes del formulario a través de los ngModel

   this.marca = { 
    idMarca:0,
    nombre:"",
    descripcion:"",
    fechaRegistro: new Date(),
    fechaVigencia:new Date(),
    certificado:"",
    estado:1,
    pais:{
      idPais:-1
      }
   }

  }
}
