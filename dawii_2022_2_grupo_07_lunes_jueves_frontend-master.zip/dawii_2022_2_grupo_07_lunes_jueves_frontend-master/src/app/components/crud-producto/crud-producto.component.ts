import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crud-producto',
  templateUrl: './crud-producto.component.html',
  styleUrls: ['./crud-producto.component.css']
})
export class CrudProductoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
