import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Cliente } from 'src/app/models/cliente.model';
import { Reclamo } from 'src/app/models/reclamo.model';
import { TipoReclamo } from 'src/app/models/tipo-reclamo.model';
import { ClienteService } from 'src/app/services/cliente.service';
import { ReclamoService } from 'src/app/services/reclamo.service';
import { TipoReclamoService } from 'src/app/services/tipo-reclamo.service';

@Component({
  selector: 'app-crud-reclamo',
  templateUrl: './crud-reclamo.component.html',
  styleUrls: ['./crud-reclamo.component.css'],
})
export class CrudReclamoComponent implements OnInit {
  reclamos: Reclamo[] = [];
  descripcion: string = '';

  tipoReclamo: TipoReclamo[] = [];
  cliente: Cliente[] = [];
  reclamo: Reclamo = {
    tipoReclamo: {
      idTipoReclamo: -1,
    },
    cliente: {
      idCliente: -1,
    },
  };

  constructor(
    private reclamoService: ReclamoService,
    private tipoReclamoService: TipoReclamoService,
    private clienteService: ClienteService
  ) {
    this.cargarCombo();
  }


  cargarCombo(){
    this.tipoReclamoService
      .listaTipoReclamo()
      .subscribe((x) => (this.tipoReclamo = x));

    this.clienteService.listaCliente().subscribe((x) => (this.cliente = x));
  }

  consulta() {
    this.reclamoService
      .consultaReclamoPorDescripcion(
        this.descripcion == '' ? 'todos' : this.descripcion
      )
      .subscribe((x) => (this.reclamos = x));
  }
  limpiar() {
    this.reclamo = {
      idReclamo: 0,
      descripcion: '',
      estado: -1,
      cliente: { idCliente: -1 },
      tipoReclamo: { idTipoReclamo: -1 }
    };
  }

  registra() {
    this.reclamoService.registraCrudReclamo(this.reclamo).subscribe((x) => {
      this.cargarCombo();
      document.getElementById('btn_reg_cerrar')?.click();
      alert(x.mensaje);

      this.consulta();
    });
    this.limpiar();
  }

  busca(aux: Reclamo) {
    this.reclamo = aux;
  }

  actualiza() {
    this.reclamoService.actualizaCrudReclamo(this.reclamo).subscribe((x) => {
      alert(x.mensaje);
      document.getElementById('btn_act_cerrar')?.click();
      this.consulta();
    });
    this.limpiar();
  }
  cambioEstado(aux: Reclamo) {
    aux.estado = aux.estado == 1 ? 0 : 1;
    this.reclamoService.actualizaCrudReclamo(aux).subscribe();
  }

  ngOnInit(): void {}
}
