import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crud-sede',
  templateUrl: './crud-sede.component.html',
  styleUrls: ['./crud-sede.component.css']
})
export class CrudSedeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
