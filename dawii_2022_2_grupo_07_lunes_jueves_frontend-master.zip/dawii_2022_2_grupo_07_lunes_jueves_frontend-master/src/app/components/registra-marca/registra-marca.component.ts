import { Component, OnInit } from '@angular/core';
import { Pais } from 'src/app/models/pais.model';
import { Marca } from 'src/app/models/marca.model';
import { MarcaService } from 'src/app/services/marca.service';
import { PaisService } from 'src/app/services/pais.service';

@Component({
  selector: 'app-registra-marca',
  templateUrl: './registra-marca.component.html',
  styleUrls: ['./registra-marca.component.css']
})
export class RegistraMarcaComponent implements OnInit {

  pais: Pais[]=[];
  marca: Marca= {
    pais:{
    idPais:-1
  }};
  
  constructor(private paisService:PaisService,private marcaService:MarcaService) { 
    this.paisService.listaPais().subscribe(
      (x) => this.pais=x
    );
  }

  insertar(){
    this.marcaService.insertaMarca(this.marca).subscribe(
      (x)=> alert(x.mensaje)
    );
  }

  ngOnInit(): void {
  }

}
