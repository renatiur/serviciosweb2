import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registra-sede',
  templateUrl: './registra-sede.component.html',
  styleUrls: ['./registra-sede.component.css']
})
export class RegistraSedeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
