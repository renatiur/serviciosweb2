import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registra-usuario',
  templateUrl: './registra-usuario.component.html',
  styleUrls: ['./registra-usuario.component.css']
})
export class RegistraUsuarioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
