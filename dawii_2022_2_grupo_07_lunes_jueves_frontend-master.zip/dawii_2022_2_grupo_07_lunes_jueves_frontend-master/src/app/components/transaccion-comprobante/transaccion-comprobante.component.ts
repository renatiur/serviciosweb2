import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transaccion-comprobante',
  templateUrl: './transaccion-comprobante.component.html',
  styleUrls: ['./transaccion-comprobante.component.css']
})
export class TransaccionComprobanteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
