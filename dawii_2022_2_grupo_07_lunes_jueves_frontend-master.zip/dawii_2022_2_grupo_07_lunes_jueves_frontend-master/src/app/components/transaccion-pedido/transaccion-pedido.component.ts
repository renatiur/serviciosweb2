import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transaccion-pedido',
  templateUrl: './transaccion-pedido.component.html',
  styleUrls: ['./transaccion-pedido.component.css']
})
export class TransaccionPedidoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
