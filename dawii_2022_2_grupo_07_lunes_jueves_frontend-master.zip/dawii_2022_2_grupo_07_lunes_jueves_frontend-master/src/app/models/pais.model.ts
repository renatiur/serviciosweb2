
export class Pais {
    idPais?:number;
    iso?:string;
    nombre?:string; 
}
