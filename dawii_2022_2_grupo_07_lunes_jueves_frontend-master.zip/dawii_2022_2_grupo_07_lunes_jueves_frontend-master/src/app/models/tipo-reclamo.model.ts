export class TipoReclamo {
    idTipoReclamo?:number;
	descripcion?:string;
    estado?:number;
}
