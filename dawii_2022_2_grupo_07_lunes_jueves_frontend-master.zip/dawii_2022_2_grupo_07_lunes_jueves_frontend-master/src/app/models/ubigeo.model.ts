export class Ubigeo {

    idUbigeo?:number;
    departamento?:string;
    provincia?:string;
    distrito?:string

}
