import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppSettings } from '../app.settings';
import { Cliente } from '../models/cliente.model';

const baseUrlUtil = AppSettings.API_ENDPOINT+ '/util';
const baseUrlCliente = AppSettings.API_ENDPOINT+ '/cliente';

@Injectable({
  providedIn: 'root'
})
export class ClienteService {


  constructor(private http:HttpClient) { }

  listaCliente():Observable<Cliente[]>{
    return this.http.get<Cliente[]>(baseUrlCliente+"/listaCliente");
  }

  registraCliente(cliente: Cliente):Observable<any>{
    return this.http.post<any>(baseUrlCliente+"/RegistaCliente", cliente);
  }

  Consultar(nombre:string,dni:string,idubigeo:number,estado:number):Observable<any>{
    const params = new HttpParams()
    .set("nombre",nombre)
    .set("dni",dni)
    .set("idUbigeo",idubigeo)
    .set("estado",estado);
    return this.http.get<any>(baseUrlCliente+"/listaFiltroCliente", {params});
  }

  SaveCliente(cliente: any):Observable<any>{
    return this.http.post<any>(baseUrlCliente+"/SaveCliente", cliente);
  }

  SaveEstado(cliente: any):Observable<any>{
    return this.http.post<any>(baseUrlCliente+"/SaveEstado", cliente);
  }

  Eliminar(id:number):Observable<any>{
    const params = new HttpParams()
    .set("id",id);
    return this.http.delete<any>(baseUrlCliente+"/DeleteCliente", {params});
  }




}
