import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppSettings } from '../app.settings';
import { Marca } from '../models/marca.model';

const baseUrlUtil = AppSettings.API_ENDPOINT+ '/util';
const baseUrlMarca = AppSettings.API_ENDPOINT+ '/marca';

@Injectable({
  providedIn: 'root',
})
export class MarcaService {

  constructor(private http: HttpClient) {  }

  listaMarca(): Observable<Marca[]> {
    return this.http.get<Marca[]>(baseUrlUtil + '/listaMarca');
  }

  consultaMarca(nombre:string,fecInicio:string,fecFin:string,certificado:string,estado:number,idPais:number):Observable<any>{
    const params = new HttpParams().set("nombre",nombre).set("fecInicio",fecInicio).set("fecFin",fecFin).set("certificado",certificado).set("estado",estado).set("idPais",idPais);
    return this.http.get<any>(baseUrlMarca+"/listaMarcaConParametros",{params});
  }

  listaMarcaNom(filtro:string):Observable<Marca[]> {
    return this.http.get<Marca[]>(baseUrlMarca + "/listaMarcaPorNombreLike/"+ filtro);
  } 

  insertaMarca(data:Marca):Observable<any>{
    return this.http.post(baseUrlMarca+"/registraMarca",data);
  }

  actualizaMarca(data:Marca):Observable<any>{
    return this.http.put(baseUrlMarca+"/actualizaMarca",data);
  }
}
