import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Reclamo } from '../models/reclamo.model';
import { AppSettings } from '../app.settings';

const baseUrlUtil = AppSettings.API_ENDPOINT + '/util';
const baseUrlReclamo = AppSettings.API_ENDPOINT + '/reclamo';
const baseUrlCrudReclamo = AppSettings.API_ENDPOINT + '/crudReclamo';

@Injectable({
  providedIn: 'root',
})
export class ReclamoService {
  constructor(private http: HttpClient) {}

  registraReclamo(data: Reclamo): Observable<any> {
    return this.http.post(baseUrlReclamo, data);
  }

  consultaReclamo(
    reclamo: number,
    descripcion: string,
    tipo: number,
    estado: number
  ): Observable<any> {
    const params = new HttpParams()
      .set('idReclamo', reclamo)
      .set('descripcion', descripcion)
      .set('idTipoReclamo', tipo)
      .set('estado',estado);
    return this.http.get<any>(baseUrlReclamo + '/listaReclamoConParametros', {
      params
    });
  }

  consultaReclamoPorDescripcion(descripcion: any): Observable<any> {
    return this.http.get(baseUrlCrudReclamo+'/listaReclamoPorDescripcion/'+descripcion);
  }

  registraCrudReclamo(data: Reclamo): Observable<any> {
    return this.http.post(baseUrlCrudReclamo+'/registraReclamo', data);
  }

  actualizaCrudReclamo(data: Reclamo): Observable<any> {
    return this.http.put(baseUrlCrudReclamo+'/actualizaReclamo', data);
  }

  
}
